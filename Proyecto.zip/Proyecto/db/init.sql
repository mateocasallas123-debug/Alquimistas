-- db/init.sql
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL, -- 'alquimista' or 'supervisor'
  specialties TEXT
);

CREATE TABLE IF NOT EXISTS materials (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  stock INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS missions (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'open',
  created_by INT REFERENCES users(id),
  assigned_to INT REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS transmutations (
  id SERIAL PRIMARY KEY,
  requester INT REFERENCES users(id),
  material_ids TEXT,
  estimated_cost INT,
  result TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audits (
  id SERIAL PRIMARY KEY,
  transmutation_id INT REFERENCES transmutations(id),
  message TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- sample data
INSERT INTO users (username, password_hash, role, specialties) VALUES
('edward','$2a$10$EXAMPLEHASH','alquimista','automail,metal'),
('al','$2a$10$EXAMPLEHASH','alquimista','defensa'),
('roy','$2a$10$EXAMPLEHASH','supervisor','combate,comando')
ON CONFLICT DO NOTHING;

INSERT INTO materials (name, stock) VALUES
('Aurum', 100),
('Hierro', 500),
('Mercurio', 50)
ON CONFLICT DO NOTHING;
