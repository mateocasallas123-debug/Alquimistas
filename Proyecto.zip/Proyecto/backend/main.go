package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gorilla/mux"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"

	"github.com/alquimia/backend/handlers"
	"github.com/alquimia/backend/models"
)

func main() {
	// Read DATABASE_URL or default local connection
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		dsn = "host=localhost user=alquimia password=alquimia dbname=alquimia port=5432 sslmode=disable"
	}

	// Connect DB
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("Failed to connect database:", err)
	}

	// Migrations
	if err := db.AutoMigrate(
		&models.User{},
		&models.Material{},
		&models.Mission{},
		&models.Transmutation{},
		&models.Audit{},
	); err != nil {
		log.Fatal(err)
	}

	// Seed
	var count int64
	db.Model(&models.User{}).Count(&count)
	if count == 0 {
		handlers.Seed(db)
	}

	// Router
	r := mux.NewRouter()
	api := r.PathPrefix("/api").Subrouter()

	h := handlers.NewHandler(db)

	// Auth
	api.HandleFunc("/register", h.Register).Methods("POST")
	api.HandleFunc("/login", h.Login).Methods("POST")

	// Protected routes
	api.HandleFunc("/alquimistas", h.AuthMiddleware(h.ListUsers)).Methods("GET")
	api.HandleFunc("/alquimistas", h.AuthMiddleware(h.CreateUser)).Methods("POST")

	api.HandleFunc("/materials", h.AuthMiddleware(h.ListMaterials)).Methods("GET")
	api.HandleFunc("/materials", h.AuthMiddleware(h.CreateMaterial)).Methods("POST")

	api.HandleFunc("/missions", h.AuthMiddleware(h.ListMissions)).Methods("GET")
	api.HandleFunc("/missions", h.AuthMiddleware(h.CreateMission)).Methods("POST")

	api.HandleFunc("/transmutations", h.AuthMiddleware(h.CreateTransmutation)).Methods("POST")
	api.HandleFunc("/transmutations", h.AuthMiddleware(h.ListTransmutations)).Methods("GET")

	api.HandleFunc("/audits", h.AuthMiddleware(h.ListAudits)).Methods("GET")

	// Websocket
	r.HandleFunc("/ws", h.WebsocketEndpoint)

	// Swagger JSON file
	r.HandleFunc("/swagger.json", func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, "./swagger.json")
	})

	// HTTP server
	srv := &http.Server{
		Handler:      r,
		Addr:         ":8080",
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}

	fmt.Println("Backend running on http://localhost:8080")

	if err := srv.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
