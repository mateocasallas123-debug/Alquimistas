﻿#!/usr/bin/env bash
set -euo pipefail

HOST=${DB_HOST:-db}
USER=${DB_USER:-alquimia}
RETRIES=30
SLEEP=2

i=0
until pg_isready -h "$HOST" -U "$USER" >/dev/null 2>&1; do
  i=$((i+1))
  echo "Esperando a Postgres ${HOST}... intento ${i}/${RETRIES}"
  if [ "$i" -ge "$RETRIES" ]; then
    echo "Postgres no respondió después de ${RETRIES} intentos" >&2
    exit 1
  fi
  sleep "$SLEEP"
done

exec "$@"
