package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/alquimia/backend/models"

	"github.com/dgrijalva/jwt-go"
	"github.com/go-redis/redis/v8"
	"github.com/gorilla/websocket"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type Handler struct {
	db       *gorm.DB
	redis    *redis.Client
	upgrader websocket.Upgrader
	clients  map[*websocket.Conn]bool
}

func NewHandler(db *gorm.DB) *Handler {
	r := redis.NewClient(&redis.Options{
		Addr: getEnv("REDIS_ADDR", "localhost:6379"),
	})
	h := &Handler{db: db, redis: r, upgrader: websocket.Upgrader{}, clients: make(map[*websocket.Conn]bool)}
	go h.worker()
	return h
}

func getEnv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

var jwtSecret = []byte(getEnv("JWT_SECRET", "secret"))

func (h *Handler) Seed(db *gorm.DB) {
	Seed(db)
}

func Seed(db *gorm.DB) {
	users := []models.User{
		{Username: "edward", Role: "alquimista", Specialties: "automail,metal"},
		{Username: "roy", Role: "supervisor", Specialties: "comando"},
	}
	for _, u := range users {
		if u.Username == "" {
			continue
		}
		var ex models.User
		if err := db.Where("username = ?", u.Username).First(&ex).Error; errors.Is(err, gorm.ErrRecordNotFound) {
			hash, _ := bcrypt.GenerateFromPassword([]byte("password"), bcrypt.DefaultCost)
			u.PasswordHash = string(hash)
			db.Create(&u)
		}
	}
}

func (h *Handler) Register(w http.ResponseWriter, r *http.Request) {
	var p struct{ Username, Password, Role, Specialties string }
	if err := json.NewDecoder(r.Body).Decode(&p); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	hash, _ := bcrypt.GenerateFromPassword([]byte(p.Password), bcrypt.DefaultCost)
	u := models.User{Username: p.Username, PasswordHash: string(hash), Role: p.Role, Specialties: p.Specialties}
	if err := h.db.Create(&u).Error; err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	w.WriteHeader(201)
	json.NewEncoder(w).Encode(u)
}

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	var cred struct{ Username, Password string }
	if err := json.NewDecoder(r.Body).Decode(&cred); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	var u models.User
	if err := h.db.Where("username = ?", cred.Username).First(&u).Error; err != nil {
		http.Error(w, "invalid credentials", 401)
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(cred.Password)) != nil {
		http.Error(w, "invalid credentials", 401)
		return
	}
	t := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"user_id": u.ID,
		"role":    u.Role,
		"exp":     time.Now().Add(24 * time.Hour).Unix(),
	})
	token, _ := t.SignedString(jwtSecret)
	json.NewEncoder(w).Encode(map[string]string{"token": token})
}

func (h *Handler) AuthMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		if auth == "" {
			http.Error(w, "missing auth", 401)
			return
		}
		parts := strings.Split(auth, "Bearer ")
		if len(parts) != 2 {
			http.Error(w, "invalid token", 401)
			return
		}
		tok := parts[1]
		token, err := jwt.Parse(tok, func(token *jwt.Token) (interface{}, error) { return jwtSecret, nil })
		if err != nil || !token.Valid {
			http.Error(w, "invalid token", 401)
			return
		}
		ctx := context.WithValue(r.Context(), "jwt", token.Claims)
		next(w, r.WithContext(ctx))
	}
}

func (h *Handler) ListUsers(w http.ResponseWriter, r *http.Request) {
	var users []models.User
	h.db.Find(&users)
	json.NewEncoder(w).Encode(users)
}

func (h *Handler) CreateUser(w http.ResponseWriter, r *http.Request) {
	var u models.User
	if err := json.NewDecoder(r.Body).Decode(&u); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	hash, _ := bcrypt.GenerateFromPassword([]byte(u.PasswordHash), bcrypt.DefaultCost)
	u.PasswordHash = string(hash)
	if err := h.db.Create(&u).Error; err != nil {
		http.Error(w, err.Error(), 500)
		return
	}
	json.NewEncoder(w).Encode(u)
}

func (h *Handler) ListMaterials(w http.ResponseWriter, r *http.Request) {
	var m []models.Material
	h.db.Find(&m)
	json.NewEncoder(w).Encode(m)
}
func (h *Handler) CreateMaterial(w http.ResponseWriter, r *http.Request) {
	var m models.Material
	if err := json.NewDecoder(r.Body).Decode(&m); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	h.db.Create(&m)
	json.NewEncoder(w).Encode(m)
}

func (h *Handler) ListMissions(w http.ResponseWriter, r *http.Request) {
	var ms []models.Mission
	h.db.Find(&ms)
	json.NewEncoder(w).Encode(ms)
}
func (h *Handler) CreateMission(w http.ResponseWriter, r *http.Request) {
	var m models.Mission
	if err := json.NewDecoder(r.Body).Decode(&m); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	h.db.Create(&m)
	json.NewEncoder(w).Encode(m)
}

func (h *Handler) CreateTransmutation(w http.ResponseWriter, r *http.Request) {
	var t models.Transmutation
	if err := json.NewDecoder(r.Body).Decode(&t); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	t.Status = "pending"
	h.db.Create(&t)

	job, _ := json.Marshal(map[string]interface{}{"transmutation_id": t.ID})
	h.redis.RPush(context.Background(), "transmutation_jobs", job)
	json.NewEncoder(w).Encode(t)
}

func (h *Handler) ListTransmutations(w http.ResponseWriter, r *http.Request) {
	var ts []models.Transmutation
	h.db.Order("created_at desc").Find(&ts)
	json.NewEncoder(w).Encode(ts)
}

func (h *Handler) ListAudits(w http.ResponseWriter, r *http.Request) {
	var as []models.Audit
	h.db.Order("created_at desc").Find(&as)
	json.NewEncoder(w).Encode(as)
}

func (h *Handler) worker() {
	ctx := context.Background()
	for {
		res, err := h.redis.BLPop(ctx, 0*time.Second, "transmutation_jobs").Result()
		if err != nil {
			time.Sleep(1 * time.Second)
			continue
		}
		if len(res) < 2 {
			continue
		}
		var job map[string]interface{}
		if err := json.Unmarshal([]byte(res[1]), &job); err != nil {
			continue
		}
		idf, ok := job["transmutation_id"].(float64)
		if !ok {
			continue
		}
		id := int64(idf)
		var t models.Transmutation
		if err := h.db.First(&t, id).Error; err != nil {
			continue
		}
		time.Sleep(2 * time.Second)
		t.Status = "done"
		t.Result = fmt.Sprintf("Procesada por worker at %s", time.Now().Format(time.RFC3339))
		h.db.Save(&t)

		a := models.Audit{TransmutationID: t.ID, Message: "Auto-audit: transmutación procesada"}
		h.db.Create(&a)

		h.notifyAll(map[string]interface{}{"type": "transmutation_done", "id": t.ID})
	}
}

func (h *Handler) WebsocketEndpoint(w http.ResponseWriter, r *http.Request) {
	conn, err := h.upgrader.Upgrade(w, r, nil)
	if err != nil {
		http.Error(w, "upgrade failed", 500)
		return
	}
	h.clients[conn] = true
	for {
		_, _, err := conn.ReadMessage()
		if err != nil {
			delete(h.clients, conn)
			conn.Close()
			return
		}
	}
}

func (h *Handler) notifyAll(msg interface{}) {
	for c := range h.clients {
		c.WriteJSON(msg)
	}
}
