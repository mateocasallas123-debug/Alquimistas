package models

import "time"

type User struct {
	ID uint `gorm:"primarykey" json:"id"`
	Username string `json:"username"`
	PasswordHash string `json:"-"`
	Role string `json:"role"`
	Specialties string `json:"specialties"`
	CreatedAt time.Time `json:"created_at"`
}

type Material struct {
	ID uint `gorm:"primarykey" json:"id"`
	Name string `json:"name"`
	Stock int `json:"stock"`
	CreatedAt time.Time `json:"created_at"`
}

type Mission struct {
	ID uint `gorm:"primarykey" json:"id"`
	Title string `json:"title"`
	Description string `json:"description"`
	Status string `json:"status"`
	CreatedBy uint `json:"created_by"`
	AssignedTo uint `json:"assigned_to"`
	CreatedAt time.Time `json:"created_at"`
}

type Transmutation struct {
	ID uint `gorm:"primarykey" json:"id"`
	Requester uint `json:"requester"`
	MaterialIDs string `json:"material_ids"`
	EstimatedCost int `json:"estimated_cost"`
	Result string `json:"result"`
	Status string `json:"status"`
	CreatedAt time.Time `json:"created_at"`
}

type Audit struct {
	ID uint `gorm:"primarykey" json:"id"`
	TransmutationID uint `json:"transmutation_id"`
	Message string `json:"message"`
	CreatedAt time.Time `json:"created_at"`
}
