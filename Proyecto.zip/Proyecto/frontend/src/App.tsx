import React from 'react'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'

export default function App(){
  const [token, setToken] = React.useState<string | null>(null)
  if(!token) return <Login onLogin={setToken} />
  return <Dashboard token={token} onLogout={()=>setToken(null)} />
}
