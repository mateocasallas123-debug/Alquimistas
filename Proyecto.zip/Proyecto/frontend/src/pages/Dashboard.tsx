import React from 'react'
import axios from 'axios'

export default function Dashboard({token, onLogout}:{token:string,onLogout:()=>void}){
  const [materials,setMaterials]=React.useState<any[]>([])
  React.useEffect(()=>{
    axios.get('/api/materials',{headers:{Authorization:'Bearer '+token}}).then(r=>setMaterials(r.data))
    // websocket
    const ws = new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.hostname+':8080/ws')
    ws.onmessage = (ev)=>{ console.log('ws', ev.data) }
    return ()=>ws.close()
  },[])
  return (
    <div style={{padding:20}}>
      <h2>Dashboard</h2>
      <button onClick={onLogout}>Logout</button>
      <h3>Materials</h3>
      <ul>{materials.map(m=><li key={m.id}>{m.name} — {m.stock}</li>)}</ul>
    </div>
  )
}
