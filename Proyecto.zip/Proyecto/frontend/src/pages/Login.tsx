import React from 'react'
import axios from 'axios'

export default function Login({onLogin}:{onLogin:(t:string)=>void}){
  const [u,setU]=React.useState('edward')
  const [p,setP]=React.useState('password')
  const submit = async (e:any)=>{
    e.preventDefault()
    const res = await axios.post('/api/login',{username:u,password:p})
    onLogin(res.data.token)
  }
  return (
    <div style={{padding:20}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div><input value={u} onChange={e=>setU(e.target.value)} /></div>
        <div><input type="password" value={p} onChange={e=>setP(e.target.value)} /></div>
        <button>Entrar</button>
      </form>
    </div>
  )
}
